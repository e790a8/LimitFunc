#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# @Author   : lisztomania
# @Date     : 2020/12/16 19:03
# @Software : PyCharm
# @Version  : Python 3.9.1
# @Project  : LimitFunc
# @FileName : __init__.py.py
# @Function :
from __future__ import absolute_import
from .LimitFunc import *

name = 'lisztomania'
